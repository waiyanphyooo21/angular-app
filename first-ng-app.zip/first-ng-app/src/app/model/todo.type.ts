export type Todo = {
    userId: number;
    completed: boolean;
    title: string;
    id: number;
}